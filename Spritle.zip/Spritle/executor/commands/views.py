from django.shortcuts import render

# Create your views here.
'''
def Studlogin(request):
    global em,pwd
    
    if key=="email":
        em=value
    if key=="password":
        pwd=value
        if (em ==() and pwd==()):
             return render(request,'error.html')
        else:
            return render(request,"welcome.html")

            
    return render(request, 'Studentlogin.html')

def Studsignup(request):
    return render(request, 'Studentsignup.html')

def dashboard(request):
    return render(request, 'welcome.html')
'''